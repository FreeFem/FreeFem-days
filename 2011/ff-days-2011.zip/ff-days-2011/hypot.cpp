// to compile "ff-c++ hypot.cpp -Dxxxx" if freefem++ version  is after 3.16
// or  "ff-c++ hypot.cpp"  otherwise 
#include "ff++.hpp"
#include <cmath> 
void initt(){
 Global.Add("hypot","(",new OneOperator2<double,double,double>(hypot));
}

#ifdef xxxx
LOADFUNC(initt);
#else
struct INIT {  INIT() {initt();} };
static INIT trulututu; 
#endif
